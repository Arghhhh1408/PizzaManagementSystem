package controller;

import dal.MenuItemDAO;
import dal.PromotionDAO;
import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.IOException;
import java.util.*;
import model.MenuItem;
import model.Promotion;
import java.util.concurrent.ThreadLocalRandom;

@WebServlet(name = "HomeServlet", urlPatterns = {"/HomePage"})
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        MenuItemDAO dao = new MenuItemDAO();
        Map<String, List<MenuItem>> menuByCategory = dao.getAvailableItemsByCategory();
        request.setAttribute("menuByCategory", menuByCategory);

        // 🔹 Pagination cho voucher
        int page = 1;
        int pageSize = 5;
        String pageParam = request.getParameter("page");
        if (pageParam != null) {
            try {
                page = Integer.parseInt(pageParam);
            } catch (NumberFormatException e) {
                page = 1;
            }
        }

        PromotionDAO promoDAO = new PromotionDAO();
        List<Promotion> activePromotions = promoDAO.getActivePromotionsPaging(page, pageSize);
        int totalPromotions = promoDAO.getTotalActivePromotions();
        int totalPages = (int) Math.ceil((double) totalPromotions / pageSize);

        request.setAttribute("activePromotions", activePromotions);
        request.setAttribute("currentPage", page);
        request.setAttribute("totalPages", totalPages);

        // 🔹 Phần voucher message, discount như cũ
        HttpSession session = request.getSession(true); // tạo session nếu chưa có

        // 🔹 Tạo mã đơn hàng ngẫu nhiên nếu chưa có trong session
        if (session.getAttribute("orderCode") == null) {
            String orderCode = generateOrderCode();
            session.setAttribute("orderCode", orderCode);
        }

        if (session != null) {
            Object msg = session.getAttribute("voucherMessage");
            Object color = session.getAttribute("voucherColor");
            if (msg != null) {
                request.setAttribute("voucherMessage", msg);
                request.setAttribute("voucherColor", color);
                session.removeAttribute("voucherMessage");
                session.removeAttribute("voucherColor");
            }

            Object discountType = session.getAttribute("discountType");
            Object discountValue = session.getAttribute("discountValue");
            if (discountType != null && discountValue != null) {
                request.setAttribute("discountType", discountType);
                request.setAttribute("discountValue", discountValue);
                session.removeAttribute("discountType");
                session.removeAttribute("discountValue");
            }
        }

        request.getRequestDispatcher("HomePage.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }

    // Hàm sinh mã đơn hàng ngẫu nhiên
    private String generateOrderCode() {
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 16; i++) {
            sb.append(chars.charAt(ThreadLocalRandom.current().nextInt(chars.length())));
        }
        return sb.toString();
    }

}
