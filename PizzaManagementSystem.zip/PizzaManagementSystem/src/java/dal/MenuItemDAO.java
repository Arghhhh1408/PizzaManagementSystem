package dal;

import java.sql.*;
import java.util.*;
import model.MenuItem;

public class MenuItemDAO {

    public Map<String, List<MenuItem>> getAvailableItemsByCategory() {
        Map<String, List<MenuItem>> categoryMap = new LinkedHashMap<>();
        String sql = "SELECT Name, Price, Category FROM MenuItem WHERE Status = 'Available' ORDER BY Category";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement ps = conn.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String category = rs.getString("Category");
                MenuItem item = new MenuItem();
                item.setName(rs.getString("Name"));
                item.setPrice(rs.getDouble("Price"));
                item.setCategory(category);
                categoryMap.computeIfAbsent(category, k -> new ArrayList<>()).add(item);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return categoryMap;
    }

}
